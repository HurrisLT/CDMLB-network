import base64
import json
import os
import shutil
import zipfile

from pyspark.ml.classification import LogisticRegressionModel, DecisionTreeClassificationModel
from pyspark.mllib.evaluation import MulticlassMetrics

from flask import Flask, request, make_response
from pyspark.ml.feature import VectorAssembler
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, split, explode, explode_outer, length, size
from pyspark.sql.types import DoubleType, IntegerType
from datetime import datetime

app = Flask(__name__)


class DataRow:
    def __init__(self, label, data):
         self.label = label
         self.data = data


class Result:
    def __init__(self, res, probability):
        self.res = res
        self.probability = probability


class Probability:
    def __init__(self, type, values):
        self.type = type
        self.values = values


# def calculate_results(mltype):
#     data_file = []
#     results = []
#
#     # getting request data request also should include array of clumns that should be features and column for label
#     # [x,y] "class"
#     now = datetime.now()
#     data_path = "./data"
#     date_time = now.strftime('%H%M%S%f')
#     file_name = "/tempData" + date_time + ".json"
#     full_data_path = data_path + file_name
#     print(full_data_path)
#
#     request_data = request.get_data()
#     ml_data_request = json.loads(request_data)
#     # print(ml_data_request)
#     ml_data = ml_data_request["Data"]
#
#     for i, val in enumerate(ml_data["Class"]):
#         data_file.append(DataRow(val, ml_data["xData"][i], ml_data["yData"][i]))
#
#     json_str = json.dumps([ob.__dict__ for ob in data_file])
#     # converting string to json
#     json_data = json.loads(json_str)
#
#
#     # saving to temp file
#     with open(full_data_path, 'a') as temp_data:
#         json.dump(json_data, temp_data)
#
#     # launching spark enviroment
#     spark = SparkSession.builder.appName("SparkAPI").config("spark.some.config.option",
#                                                                       "some-value").getOrCreate()
#     # # reading temp file
#     #
#     # #this should be changed to load data from variable not file
#     raw_df = spark.read.load(full_data_path, format="json", multiLine="false")
#     #
#     # # parsing and casting file to correct data types
#     modified_df = raw_df.withColumn("x", raw_df["x"].cast(DoubleType()))
#     modified_df = modified_df.withColumn("y", modified_df["y"].cast(DoubleType()))
#     modified_df = modified_df.withColumn("label", modified_df["y"].cast(IntegerType()))
#     #
#     # #assembling feature column
#     assembler_features = VectorAssembler(
#         inputCols=['x', 'y'],
#         outputCol='features')
#
#     # #marking label column
#
#     training_df = assembler_features.transform(modified_df)
#     #ml_name = ml_data_request["Model"]["Name"]
#     #print(ml_name)
#     ml_model_bytes = ml_data_request["Model"]["File"]
#     # this will not be neded when model sends correct model base64 string
#     # -----
#     ml_model_bytes = ml_model_bytes.replace('b\'', '')
#     ml_model_bytes = ml_model_bytes.replace('\'', '')
#     # -----
#     unzipped_model_dir = "./unzippedModels" + date_time
#
#     model_dir_path = "./models"
#     model_file_name = "/DTzip" + date_time + ".zip"
#     full_model_path = model_dir_path + model_file_name
#     unzipped_model_path = "./unzippedModels" + date_time
#     os.mkdir(unzipped_model_path)
#
#     # creating zip file from BASE64 string
#     try:
#         file_content = base64.urlsafe_b64decode(ml_model_bytes)
#         with open(full_model_path, "wb") as f:
#             f.write(file_content)
#     except Exception as e:
#         print(str(e))
#
#     # extracting zip file
#     with zipfile.ZipFile(full_model_path, 'r') as zip_ref:
#         zip_ref.extractall(unzipped_model_dir)
#
#     # loading extracted model
#     if mltype == "DecisionTree":
#         persisted_model = DecisionTreeClassificationModel.load(unzipped_model_dir)
#     if mltype == "LogisticRegression":
#         persisted_model = LogisticRegressionModel.load(unzipped_model_dir)
#
#     prediction = persisted_model.transform(training_df)
#
#     # Use this part to debug if found probabilities ar correct
#     # selected = prediction.select("label", "prediction", "probability")
#     # for row in selected.collect():
#     #    print(row)
#     second_element = udf(lambda v: float(v[1]), DoubleType())
#     probability_list = prediction.select(second_element('probability'))
#     for row in probability_list.collect():
#         probability = row['<lambda>(probability)']
#         rounded_probability = round(probability, 4)
#         results.append(1 - rounded_probability)
#
#     result_dictionary = {"Results": results}
#     json_results = json.dumps(result_dictionary)
#     byte_results = json_results.encode('utf8')
#     http_response = make_response(byte_results)
#
#     # removing temp files
#     if os.path.exists(full_data_path):
#         os.remove(full_data_path)
#         os.remove(full_model_path)
#         shutil.rmtree(unzipped_model_path)
#     else:
#         print("The file does not exist")
#
#     return http_response
def calculate_resultsEEG(mltype):
    if request.method == 'POST':

        data_file = []
        results = []

        now = datetime.now()
        data_path = "./data"
        date_time = now.strftime('%H%M%S%f')
        file_name = "/tempData" + date_time + ".json"
        full_data_path = data_path + file_name
        print(full_data_path)

        request_data = request.get_data()
        ml_data_request = json.loads(request_data)
        print(ml_data_request["Data"]["DataTable"])
        ml_data = ml_data_request["Data"]

        for i, val in enumerate(ml_data["Class"]):
            row_data = []
            for j, col in enumerate(ml_data["DataTable"]):
                row_data.append(col[i])
            data_file.append(DataRow(val, row_data))

        json_str = json.dumps([ob.__dict__ for ob in data_file])
        # converting string to json
        json_data = json.loads(json_str)

        print(json_data)

        with open(full_data_path, 'a') as temp_data:
            json.dump(json_data, temp_data)

        spark = SparkSession.builder.appName("test").config("spark.some.config.option", "some-value").getOrCreate()
        raw_df = spark.read.load(full_data_path, format="json", multiLine="false")
        # we cast label from string to int
        modified_df = raw_df.withColumn("label", raw_df["label"].cast(IntegerType()))
        s = modified_df.withColumn("size", size(modified_df.data))
        dataColumns = []
        for i in range(0, s.collect()[0][2]):
            dataColumns.append("data" + str(i))
            modified_df = modified_df.withColumn("data" + str(i), modified_df.data[i].cast(DoubleType()))
        modified_df = modified_df.drop('data')

        print(modified_df.toJSON().collect())

        assembler_features = VectorAssembler(
            inputCols=dataColumns,
            outputCol='features')

        validation_df = assembler_features.transform(modified_df)
        # ml_name = ml_data_request["Model"]["Name"]
        # print(ml_name)
        ml_model_bytes = ml_data_request["Model"]["File"]
        # this will not be neded when model sends correct model base64 string
        # -----
        ml_model_bytes = ml_model_bytes.replace('b\'', '')
        ml_model_bytes = ml_model_bytes.replace('\'', '')
        # -----

        model_dir_path = "./models"
        model_file_name = "/DTzip" + date_time + ".zip"
        full_model_path = model_dir_path + model_file_name
        unzipped_model_path = "./unzippedModels" + date_time
        os.mkdir(unzipped_model_path)

        # creating zip file from BASE64 string
        try:
            file_content = base64.urlsafe_b64decode(ml_model_bytes)
            with open(full_model_path, "wb") as f:
                f.write(file_content)
        except Exception as e:
            print(str(e))

        with zipfile.ZipFile(full_model_path, 'r') as zip_ref:
            zip_ref.extractall(unzipped_model_path)
            # loading extracted model

            # loading extracted model
            if mltype == "DecisionTree":
                persisted_model = DecisionTreeClassificationModel.load(unzipped_model_path)
            if mltype == "LogisticRegression":
                persisted_model = LogisticRegressionModel.load(unzipped_model_path)

        prediction = persisted_model.transform(validation_df)

        # Use this part to debug if found probabilities ar correct
        # selected = prediction.select("label", "prediction", "probability")
        # for row in selected.collect():
        #    print(row)
        second_element = udf(lambda v: float(v[1]), DoubleType())
        probability_list = prediction.select(second_element('probability'))
        for row in probability_list.collect():
            probability = row['<lambda>(probability)']
            rounded_probability = round(probability, 4)
            results.append(1 - rounded_probability)

        result_dictionary = {"Results": results}
        print(result_dictionary)
        json_results = json.dumps(result_dictionary)
        byte_results = json_results.encode('utf8')

        http_response = make_response(byte_results)
        return http_response


@app.route('/apiValidateDT', methods=['GET', 'POST'])
def api_validateDT():
    if request.method == 'GET':
        print('GET of validationDT method complete')
        return 'Hello World!'
    if request.method == 'POST':
        http_response = calculate_resultsEEG("DecisionTree")
        return http_response


@app.route('/apiTestDT', methods=['GET', 'POST'])
def api_TestDT():
    if request.method == 'GET':
        print('Get of Test method complete')
        return 'Hello World!'
    if request.method == 'POST':

        SparkSession.builder.appName("LogisticRegression").config("spark.some.config.option",
                                                                  "some-value").getOrCreate()
        # reading temp file
        now = datetime.now()
        date_time = now.strftime('%H%M%S%f')
        request_data = request.get_data()
        ml_data_request = json.loads(request_data)
        ml_name = ml_data_request["Model"]["Name"]
        print(ml_name)
        ml_model_bytes = ml_data_request["Model"]["File"]
        # this will not be neded when model sends correct model base64 string
        # -----
        ml_model_bytes = ml_model_bytes.replace('b\'', '')
        ml_model_bytes = ml_model_bytes.replace('\'', '')
        # -----
        unzipped_model_dir = "./unzippedModels" + date_time

        model_dir_path = "./models"
        model_file_name = "/DTzip" + date_time + ".zip"
        full_model_path = model_dir_path + model_file_name
        unzipped_model_path = "./unzippedModels" + date_time
        os.mkdir(unzipped_model_path)

        # creating zip file from BASE64 string
        try:
            file_content = base64.urlsafe_b64decode(ml_model_bytes)
            with open(full_model_path, "wb") as f:
                f.write(file_content)
        except Exception as e:
            print(str(e))

        # extracting zip file
        with zipfile.ZipFile(full_model_path, 'r') as zip_ref:
            zip_ref.extractall(unzipped_model_dir)

        # loading extracted model
        try:
            DecisionTreeClassificationModel.load(unzipped_model_dir)
            modelValidity = {"modelValidity": 1}
        except:
            modelValidity = {"modelValidity": 0}


            if os.path.exists(full_model_path):
                os.remove(full_model_path)
                shutil.rmtree(unzipped_model_path)
            else:
                print("The file does not exist")

        http_response = make_response(modelValidity)
        return http_response

@app.route('/apiTestLR', methods=['GET', 'POST'])
def api_TestLR():
        if request.method == 'GET':
            print('Get of Test method complete')
            return 'Hello World!'
        if request.method == 'POST':

            SparkSession.builder.appName("LogisticRegression").config("spark.some.config.option",
                                                                      "some-value").getOrCreate()
            # reading temp file
            now = datetime.now()
            date_time = now.strftime('%H%M%S%f')
            request_data = request.get_data()
            ml_data_request = json.loads(request_data)
            ml_name = ml_data_request["Model"]["Name"]
            print(ml_name)
            ml_model_bytes = ml_data_request["Model"]["File"]
            # this will not be neded when model sends correct model base64 string
            # -----
            ml_model_bytes = ml_model_bytes.replace('b\'', '')
            ml_model_bytes = ml_model_bytes.replace('\'', '')
            # -----
            unzipped_model_dir = "./unzippedModels" + date_time

            model_dir_path = "./models"
            model_file_name = "/DTzip" + date_time + ".zip"
            full_model_path = model_dir_path + model_file_name
            unzipped_model_path = "./unzippedModels" + date_time
            os.mkdir(unzipped_model_path)

            # creating zip file from BASE64 string
            try:
                file_content = base64.urlsafe_b64decode(ml_model_bytes)
                with open(full_model_path, "wb") as f:
                    f.write(file_content)
            except Exception as e:
                print(str(e))

            # extracting zip file
            with zipfile.ZipFile(full_model_path, 'r') as zip_ref:
                zip_ref.extractall(unzipped_model_dir)

            # loading extracted model
            try:
                LogisticRegressionModel.load(unzipped_model_dir)
                modelValidity = {"modelValidity": 1}
            except:
                modelValidity = {"modelValidity": 0}

                if os.path.exists(full_model_path):
                    os.remove(full_model_path)
                    shutil.rmtree(unzipped_model_path)
                else:
                    print("The file does not exist")

            http_response = make_response(modelValidity)
            return http_response

# @app.route('/apiValidateEEGDT', methods=['POST'])
# def api_Data():
#     if request.method == 'POST':
#
#         data_file = []
#         results = []
#
#         now = datetime.now()
#         data_path = "./data"
#         date_time = now.strftime('%H%M%S%f')
#         file_name = "/tempData" + date_time + ".json"
#         full_data_path = data_path + file_name
#         print(full_data_path)
#
#         request_data = request.get_data()
#         ml_data_request = json.loads(request_data)
#         print(ml_data_request["Data"]["DataTable"])
#         ml_data = ml_data_request["Data"]
#
#         for i, val in enumerate(ml_data["Class"]):
#             row_data = []
#             for j, col in enumerate(ml_data["DataTable"]):
#                 row_data.append(col[i])
#             data_file.append(DataRow(val, row_data))
#
#         json_str = json.dumps([ob.__dict__ for ob in data_file])
#         # converting string to json
#         json_data = json.loads(json_str)
#
#         print(json_data)
#
#         with open(full_data_path, 'a') as temp_data:
#             json.dump(json_data, temp_data)
#
#         spark = SparkSession.builder.appName("test").config("spark.some.config.option","some-value").getOrCreate()
#         raw_df = spark.read.load(full_data_path, format="json", multiLine="false")
#         # we cast label from string to int
#         modified_df = raw_df.withColumn("label", raw_df["label"].cast(IntegerType()))
#         s = modified_df.withColumn("size", size(modified_df.data))
#         dataColumns = []
#         for i in range(0,  s.collect()[0][2]):
#             dataColumns.append("data" + str(i))
#             modified_df = modified_df.withColumn("data" + str(i), modified_df.data[i].cast(DoubleType()))
#         modified_df = modified_df.drop('data')
#
#         print(modified_df.toJSON().collect())
#
#         assembler_features = VectorAssembler(
#             inputCols=dataColumns,
#             outputCol='features')
#
#         validation_df = assembler_features.transform(modified_df)
#
#         model_dir_path = "./models"
#         model_file_name = "/DTzip" + date_time + ".zip"
#         full_model_path = model_dir_path + model_file_name
#         unzipped_model_path = "./unzippedModels" + date_time
#         os.mkdir(unzipped_model_path)
#
#         with zipfile.ZipFile(full_model_path, 'r') as zip_ref:
#             zip_ref.extractall(unzipped_model_path)
#             # loading extracted model
#
#         persisted_model = DecisionTreeClassificationModel.load(unzipped_model_path)
#
#         prediction = persisted_model.transform(validation_df)
#
#         # Use this part to debug if found probabilities ar correct
#         # selected = prediction.select("label", "prediction", "probability")
#         # for row in selected.collect():
#         #    print(row)
#         second_element = udf(lambda v: float(v[1]), DoubleType())
#         probability_list = prediction.select(second_element('probability'))
#         for row in probability_list.collect():
#             probability = row['<lambda>(probability)']
#             rounded_probability = round(probability, 4)
#             results.append(1 - rounded_probability)
#
#         result_dictionary = {"Results": results}
#         print(result_dictionary)
#         json_results = json.dumps(result_dictionary)
#         byte_results = json_results.encode('utf8')
#
#         http_response = make_response(byte_results)
#         return http_response

@app.route('/apiValidateLR', methods=['GET', 'POST'])
def api_validateLR():
    if request.method == 'GET':
        print('Test complete')
        return 'succeess'
    if request.method == 'POST':
        http_response = calculate_resultsEEG("LogisticRegression")
        return http_response


if __name__ == '__main__':
    app.run(host="192.168.144.2", port=8080)
