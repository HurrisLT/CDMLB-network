#!/bin/bash
/home/vdledger/PycharmProjects/untitled/startNetwork.sh
/home/vdledger/PycharmProjects/untitled/startSpark.sh
/home/vdledger/RFabricML/FabricML/startPlumber.sh