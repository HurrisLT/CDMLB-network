#!/bin/bash
docker network create --driver=bridge --subnet=192.168.144.0/20 --gateway=192.168.144.1 fabric_test