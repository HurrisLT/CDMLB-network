#!/bin/bash
app="sparkapi"
docker build -t ${app} /home/vdledger/PycharmProjects/untitled/
docker run -p 8080:8080 -itd --network=fabric_test --name=${app} --log-opt max-size=10m --log-opt max-file=1 ${app}