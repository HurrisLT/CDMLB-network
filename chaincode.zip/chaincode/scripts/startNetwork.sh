#!/bin/bash
/home/vdledger/PycharmProjects/untitled/start.sh
bash /home/vdledger/HLtwothree/fabric-samples/test-network/network.sh up -s couchdb -ca
bash /home/vdledger/HLtwothree/fabric-samples/test-network/network.sh createChannel -ca




