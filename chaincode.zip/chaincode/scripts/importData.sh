#!/bin/bash
# Purpose: Read Comma Separated CSV File
# Author: Vivek Gite under GPL v2.0+
# ------------------------------------------
INPUT="./data/data4096.csv"
OLDIFS=$IFS
IFS=','
I=0
Command=""
Args=""
FullCMD=""
[ ! -f $INPUT ] && { echo "$INPUT file not found"; exit 99; }
while read x y res
do
  Command="peer chaincode invoke -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com --tls true --cafile $ORDERER_CA -C mychannel -n model --peerAddresses localhost:7051 --tlsRootCertFiles ${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt --peerAddresses localhost:9051 --tlsRootCertFiles ${PWD}/organizations/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt -c '{\"Args\":[\"initTestData\",\"$x\",\"$y\",\"$res\",\"Vaidotas\",\"Data$I\"]}' -C mychannel"
 eval "$Command" 

  I=$((I + 1))
done < $INPUT
IFS=$OLDIFS
