#!/bin/bash
bash InstallChaincode13.sh

eval "peer chaincode instantiate -n model -v 0 -c'{\"Args\":[\"initModel\",\"-9.700\", \"2.61928\", \"3.12672\",\"model\",\"Vaidotas\"]}' -C myc -P \"AND('Org1MSP.member','Org1MSP.member','Org1MSP.member','Org1MSP.member','Org1MSP.member','Org1MSP.member','Org1MSP.member')\""

bash ImportModel13.sh
bash importData13.sh
bash validate13.sh
bash validateAPI13.sh
