#!/bin/bash

docker network create --driver=bridge --subnet=192.168.144.0/20 --gateway=192.168.144.1 net_test
docker build -t my-go-app .
docker run  -p 8080:8081 -itd --network=net_test --name api --log-opt max-size=10m --log-opt max-file=1 my-go-app



