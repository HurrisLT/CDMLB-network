#!/bin/bash

docker stop sparkapi
docker rm sparkapi
docker stop plumberapi
docker rm plumberapi
bash /home/vdledger/HLtwothree/fabric-samples/test-network/network.sh down
docker system prune --volumes -f





